package restaurant;

public class Deserts extends Menu{
}
