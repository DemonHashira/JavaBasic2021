package restaurant;

public abstract class Client extends Menu{

   abstract Waiters getRandomWaiter(Waiters[] array);

    abstract void makeAnOrder(Menu[] array);

    abstract void receiveTheCheck(Menu[] array);

    abstract void payTheChek(Menu[] array);

}
