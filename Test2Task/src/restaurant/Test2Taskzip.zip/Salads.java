package restaurant;

public class Salads extends Menu{
}
