package restaurant;

public class NonAlcoholDrinks extends Menu{
}
