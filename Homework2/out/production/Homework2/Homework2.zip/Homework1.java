
public class Homework1 {
    public static void main(String[] args) {
        for (int i = -5; i <= 5; i++) {
            if (i % 2 == 0) {
                continue;
            }
            System.out.println(i);
        }
    }
}
