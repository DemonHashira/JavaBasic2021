package restaurant;

public abstract class Client extends Menu{

   abstract Waiters getRandomWaiter(Waiters[] array);

    abstract void makeAnOrder();

    abstract void receiveTheCheck();

    abstract void payTheChek();

}
