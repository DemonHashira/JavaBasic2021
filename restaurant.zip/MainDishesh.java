package restaurant;

public class MainDishesh extends Menu{
}
