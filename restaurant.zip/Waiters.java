package restaurant;

public class Waiters {

    String name;
    int moneyFromTips;

    Waiters() {};

    Waiters (String name) {
        if (name != null && !(name.equals(""))) {
            this.name = name;
        }
    }
}
