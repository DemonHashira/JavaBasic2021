package restaurant;

public class Demo extends Restourant {
    public static void main(String[] args) {

        Restourant lozata = new Restourant("Lozata","Elenovo",1000);

        Waiters waiter1 = new Waiters("Ivan");
        Waiters waiter2 = new Waiters("Ivaylo");
        Waiters waiter3 = new Waiters("Kiril");

        lozata.waiters[0] = waiter1;
        lozata.waiters[1] = waiter2;
        lozata.waiters[2] = waiter3;

        ClientStudent student = new ClientStudent(20);
        ClientStudent student2 = new ClientStudent(20);
        ClientStudent student3 = new ClientStudent(20);
        ClientStudent student4 = new ClientStudent(20);

        ClientProgrammer programmer = new ClientProgrammer(50);
        ClientProgrammer programmer2 = new ClientProgrammer(50);
        ClientProgrammer programmer3 = new ClientProgrammer(50);
        ClientProgrammer programmer4 = new ClientProgrammer(50);

        for (int i = 1; i < lozata.menu.length; i++) {
            if (i <= 5) {
                lozata.menu[i] = new Salads();
                lozata.menu[i].dishName = "Caesar Salad";
                lozata.menu[i].dishPrice = 10;
                lozata.menu[i].dishGramaj = 300;
            } else if (i <= 10) {
                lozata.menu[i] = new Salads();
                lozata.menu[i].dishName = "Greek Salad";
                lozata.menu[i].dishPrice = 10;
                lozata.menu[i].dishGramaj = 350;
            } else if (i <= 15) {
                lozata.menu[i] = new MainDishesh();
                lozata.menu[i].dishName = "Beef Enchiladas";
                lozata.menu[i].dishPrice = 20;
                lozata.menu[i].dishGramaj = 600;
            } else if (i <= 20) {
                lozata.menu[i] = new MainDishesh();
                lozata.menu[i].dishName = "Favorite Meatloaf";
                lozata.menu[i].dishPrice = 20;
                lozata.menu[i].dishGramaj = 690;
            } else if (i <= 25) {
                lozata.menu[i] = new Deserts();
                lozata.menu[i].dishName = "Tiramisu";
                lozata.menu[i].dishPrice = 8;
                lozata.menu[i].dishGramaj = 160;
            } else if (i <= 30) {
                lozata.menu[i] = new Deserts();
                lozata.menu[i].dishName = "Cheesecake";
                lozata.menu[i].dishPrice = 8;
                lozata.menu[i].dishGramaj = 150;
            } else if (i <= 35) {
                lozata.menu[i] = new AlcoholDrinks();
                lozata.menu[i].drinkName = "Whiskey";
                lozata.menu[i].drinkPrice = 15;
            } else if (i <= 40) {
                lozata.menu[i] = new AlcoholDrinks();
                lozata.menu[i].drinkName = "Rakija";
                lozata.menu[i].drinkPrice = 15;
            } else if (i <= 45) {
                lozata.menu[i] = new AlcoholDrinks();
                lozata.menu[i].drinkName = "Beer";
                lozata.menu[i].drinkPrice = 15;
            } else if (i <= 50) {
                lozata.menu[i] = new NonAlcoholDrinks();
                lozata.menu[i].drinkName = "Coca-Cola";
                lozata.menu[i].drinkPrice = 4;
            } else if (i <= 55) {
                lozata.menu[i] = new NonAlcoholDrinks();
                lozata.menu[i].drinkName = "Fanta";
                lozata.menu[i].drinkPrice = 4;
            } else {
                lozata.menu[i] = new NonAlcoholDrinks();
                lozata.menu[i].drinkName = "Juice";
                lozata.menu[i].drinkPrice = 4;
            }
        }
        lozata.shuffleMenu();


    }
}
