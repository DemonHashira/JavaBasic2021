package restaurant;

public class Salads extends Menu{

    Salads[] arraySalads = new Salads[10];

}
