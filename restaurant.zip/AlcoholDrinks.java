package restaurant;

public class AlcoholDrinks extends Menu {

    AlcoholDrinks[] arrayAlcohol = new AlcoholDrinks[15];

}
