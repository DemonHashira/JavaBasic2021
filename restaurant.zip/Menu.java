package restaurant;

public class Menu extends Restourant{

    String dishName;
    int dishPrice;
    int dishGramaj;
    String drinkName;
    int drinkPrice;

}
