package restaurant;

public class Restourant {

    String name;
    String address;
    int capital;
    Menu[] menu = new Menu[61];
    Waiters[] waiters = new Waiters[3];

    Restourant() {}

    Restourant(String name, String address, int capital) {
        if (name != null && !(name.equals(""))) {
            this.name = name;
        }
        if (capital > 0) {
            this.capital = capital;
        }
        if (address != null && !(address.equals(""))) {
            this.address = address;
        }
    }

    void shuffleMenu() {
        for (int count = 1; count < 61; count++) {
            int menuIndex = (int) (Math.random() * 61);

            Menu temp = this.menu[count - 1];
            this.menu[count - 1] = this.menu[menuIndex];
            this.menu[menuIndex] = temp;
        }
    }
}
