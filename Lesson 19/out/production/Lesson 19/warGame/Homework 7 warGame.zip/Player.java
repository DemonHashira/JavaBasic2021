package warGame;

public class Player {
    private int deck;
    private String name;
    private Card[] retrievedCards;
    private Card[] deckCards;

    Player() {};

    Player(String name, int deck) {
        if (name != null && !(name.equals(""))) {
            this.name = name;
        }
        if (deck == 26) {
            this.deck = deck;
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name != null && !(name.equals(""))) {
            this.name = name;
        }
    }

    public Card[] getRetrievedCards() {
        return retrievedCards;
    }

    public void setRetrievedCards(Card[] retrievedCards) {
        this.retrievedCards = retrievedCards;
    }

    public Card[] getDeckCards() {
        return deckCards;
    }

    public void setDeckCards(Card[] deckCards) {
        this.deckCards = deckCards;
    }

    public int getDeck() {
        return deck;
    }

    public void setDeck(int deck) {
        if (deck == 26) {
            this.deck = deck;
        }
    }
}
