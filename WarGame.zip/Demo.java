package warGame;

public class Demo {
    public static void main(String[] args) {
        Player player1 = new Player("Pencho", 26);
        Player player2 = new Player("Gencho", 26);

        Card card1 = new Card("Card of 2 Club", 2);
        Card card2 = new Card("Card of 2 Diamond", 2);
        Card card3 = new Card("Card of 2 Hearts", 2);
        Card card4 = new Card("Card of 2 Spades", 2);

        Card card5 = new Card("Card of 3 Club", 3);
        Card card6 = new Card("Card of 3 Diamond", 3);
        Card card7 = new Card("Card of 3 Hearts", 3);
        Card card8 = new Card("Card of 3 Spades", 3);

        Card card9 = new Card("Card of 4 Club", 4);
        Card card10 = new Card("Card of 4 Diamond", 4);
        Card card11 = new Card("Card of 4 Hearts", 4);
        Card card12 = new Card("Card of 4 Spades", 4);

        Card card13 = new Card("Card of 5 Club", 5);
        Card card14 = new Card("Card of 5 Diamond", 5);
        Card card15 = new Card("Card of 5 Hearts", 5);
        Card card16 = new Card("Card of 5 Spades", 5);

        Card card17 = new Card("Card of 6 Club", 6);
        Card card18 = new Card("Card of 6 Diamond", 6);
        Card card19 = new Card("Card of 6 Hearts", 6);
        Card card20 = new Card("Card of 6 Spades", 6);

        Card card21 = new Card("Card of 7 Club", 7);
        Card card22 = new Card("Card of 7 Diamond", 7);
        Card card23 = new Card("Card of 7 Hearts", 7);
        Card card24 = new Card("Card of 7 Spades", 7);

        Card card25 = new Card("Card of 8 Club", 8);
        Card card26 = new Card("Card of 8 Diamond", 8);
        Card card27 = new Card("Card of 8 Hearts", 8);
        Card card28 = new Card("Card of 8 Spades", 8);

        Card card29 = new Card("Card of 9 Club", 9);
        Card card30 = new Card("Card of 9 Diamond", 9);
        Card card31 = new Card("Card of 9 Hearts", 9);
        Card card32 = new Card("Card of 9 Spades", 9);

        Card card33 = new Card("Card of 10 Club", 10);
        Card card34 = new Card("Card of 10 Diamond", 10);
        Card card35 = new Card("Card of 10 Hearts", 10);
        Card card36 = new Card("Card of 10 Spades", 10);

        Card card37 = new Card("Card of Jack Club", 11);
        Card card38 = new Card("Card of Jack Diamond", 11);
        Card card39 = new Card("Card of Jack Hearts", 11);
        Card card40 = new Card("Card of Jack Spades", 11);

        Card card41 = new Card("Card of Queen Club", 12);
        Card card42 = new Card("Card of Queen Diamond", 12);
        Card card43 = new Card("Card of Queen Hearts", 12);
        Card card44 = new Card("Card of Queen Spades", 12);

        Card card45 = new Card("Card of King Club", 13);
        Card card46 = new Card("Card of King Diamond", 13);
        Card card47 = new Card("Card of King Hearts", 13);
        Card card48 = new Card("Card of King Spades", 13);

        Card card49 = new Card("Card of Ace Club", 14);
        Card card50 = new Card("Card of Ace Diamond", 14);
        Card card51 = new Card("Card of Ace Hearts", 14);
        Card card52 = new Card("Card of Ace Spades", 14);

        Card[] array = {card1, card2, card3, card4, card5, card6, card7, card8,
                card9, card10, card11, card12, card13, card14, card15, card16, card17,
                card18, card19, card20, card21, card22, card23, card24, card25, card26};

        Card[] array2 = {card27, card28, card29, card30, card31, card32, card33, card34,
                card35, card36, card37, card38, card39, card40, card41, card42, card43,
                card44, card45, card46, card47, card48, card49, card50, card51, card52};

        Card[] allCards = {card1, card2, card3, card4, card5, card6, card7, card8,
                card9, card10, card11, card12, card13, card14, card15, card16, card17,
                card18, card19, card20, card21, card22, card23, card24, card25, card26,
                card27, card28, card29, card30, card31, card32, card33, card34,
                card35, card36, card37, card38, card39, card40, card41, card42, card43,
                card44, card45, card46, card47, card48, card49, card50, card51, card52};

        Card cardDeckPlayer1 = new Card();
        Card cardDeckPlayer2 = new Card();
        Card cardDeckForShuffle = new Card();
        cardDeckForShuffle.setCards(allCards);
        cardDeckForShuffle.shuffleCards();

        System.arraycopy(allCards, 0, array, 0, allCards.length / 2);

        int j = 0;
        for (int i = allCards.length / 2; i < allCards.length; i++) {
            array2[j] = allCards[i];
            j++;
        }

        cardDeckPlayer1.setCards(array);
        cardDeckPlayer2.setCards(array2);
        cardDeckPlayer1.shuffleCardsDeck();
        cardDeckPlayer2.shuffleCardsDeck();

        Card[] arrayRetrievedCardsPlayer1 = new Card[52];
        Card[] arrayRetrievedCardsPlayer2 = new Card[52];

        int player1CountDeck = 26;
        int player2CountDeck = 26;
        int player1TakenCards = 0;  
        int player2TakenCards = 0;
        boolean player1thirdCardIsHigher = true;
        boolean player2thridCardIsHigher = true;

        while (player1CountDeck > 0 && player2CountDeck > 0) {
            if (cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards()).getValue() > cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards()).getValue()) {
                for (int i = 0; i < arrayRetrievedCardsPlayer1.length; i++) {
                    if (arrayRetrievedCardsPlayer1[i] == null) {
                        arrayRetrievedCardsPlayer1[i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                        arrayRetrievedCardsPlayer1[++i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                        break;
                    }
                }
                player1TakenCards += 2;
                player1CountDeck--;
                player2CountDeck--;
            } else if (cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards()).getValue() < cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards()).getValue()) {
                for (int i = 0; i < arrayRetrievedCardsPlayer2.length; i++) {
                    if (arrayRetrievedCardsPlayer2[i] == null) {
                        arrayRetrievedCardsPlayer2[i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                        arrayRetrievedCardsPlayer2[++i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                        break;
                    }
                }
                player2TakenCards += 2;
                player1CountDeck--;
                player2CountDeck--;
            } else {
                if (cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards()).getValue() > cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards()).getValue()) {
                    for (int i = 0; i < arrayRetrievedCardsPlayer1.length; i++) {
                        if (arrayRetrievedCardsPlayer1[i] == null) {
                                arrayRetrievedCardsPlayer1[i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                            if (!(++i >= 51)) {
                                arrayRetrievedCardsPlayer1[++i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                            }
                            if (!(++i >= 51)) {
                                arrayRetrievedCardsPlayer1[++i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                            }
                            if (!(++i >= 51)) {
                                arrayRetrievedCardsPlayer1[++i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                            }

                            if (!(++i >= 51)) {
                                arrayRetrievedCardsPlayer1[++i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                            }
                            if (!(++i >= 51)) {
                                arrayRetrievedCardsPlayer1[++i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                            }
                            if (!(++i >= 51)) {
                                arrayRetrievedCardsPlayer1[++i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                            }
                            if (!(++i >= 51)) {
                                arrayRetrievedCardsPlayer1[++i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                            }
                            break;
                        }
                    }
                    player1TakenCards += 8;
                    player1CountDeck -= 4;
                    player2CountDeck -= 4;
                } else if (cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards()).getValue() < cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards()).getValue()) {
                    for (int i = 0; i < arrayRetrievedCardsPlayer2.length; i++) {
                        if (arrayRetrievedCardsPlayer2[i] == null) {
                                arrayRetrievedCardsPlayer2[i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                            if (!(++i >= 51)) {
                                arrayRetrievedCardsPlayer2[++i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                            }
                            if (!(++i >= 51)) {
                                arrayRetrievedCardsPlayer2[++i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                            }
                            if (!(++i >= 51)) {
                                arrayRetrievedCardsPlayer2[++i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                            }

                            if (!(++i >= 51)) {
                                arrayRetrievedCardsPlayer2[++i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                            }
                            if (!(++i >= 51)) {
                                arrayRetrievedCardsPlayer2[++i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                            }
                            if (!(++i >= 51)) {
                                arrayRetrievedCardsPlayer2[++i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                            }
                            if (!(++i >= 51)) {
                                arrayRetrievedCardsPlayer2[++i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                            }
                            break;
                        }
                    }
                    player2TakenCards += 8;
                    player2CountDeck -= 4;
                    player1CountDeck -= 4;
                } else  {
                     while (player1thirdCardIsHigher == true || player2thridCardIsHigher == true) {
                        if (cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards()).getValue() > cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards()).getValue()) {
                            for (int i = 0; i < arrayRetrievedCardsPlayer1.length; i++) {
                                if (arrayRetrievedCardsPlayer1[i] == null) {
                                        arrayRetrievedCardsPlayer1[i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                                    if (!(++i >= 51)) {
                                        arrayRetrievedCardsPlayer1[++i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                                    }
                                    if (!(++i >= 51)) {
                                        arrayRetrievedCardsPlayer1[++i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                                    }
                                    if (!(++i >= 51)) {
                                        arrayRetrievedCardsPlayer1[++i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                                    }
                                    if (!(++i >= 51)) {
                                        arrayRetrievedCardsPlayer1[++i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                                    }
                                    if (!(++i >= 51)) {
                                        arrayRetrievedCardsPlayer1[++i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                                    }
                                    if (!(++i >= 51)) {
                                        arrayRetrievedCardsPlayer1[++i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                                    }
                                    if (!(++i >= 51)) {
                                        arrayRetrievedCardsPlayer1[++i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                                    }
                                    if (!(++i >= 51)) {
                                        arrayRetrievedCardsPlayer1[++i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                                    }
                                    if (!(++i >= 51)) {
                                        arrayRetrievedCardsPlayer1[++i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                                    }
                                    break;
                                }
                            }
                            player2TakenCards += 10;
                            player1CountDeck -= 5;
                            player2CountDeck -= 5;
                            player1thirdCardIsHigher = false;
                        } else if (cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards()).getValue() < cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards()).getValue()) {
                            for (int i = 0; i < arrayRetrievedCardsPlayer2.length; i++) {
                                if (arrayRetrievedCardsPlayer2[i] == null) {
                                    arrayRetrievedCardsPlayer2[i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                                    if (!(++i >= 51)) {
                                        arrayRetrievedCardsPlayer2[++i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                                    }
                                    if (!(++i >= 51)) {
                                        arrayRetrievedCardsPlayer2[++i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                                    }
                                    if (!(++i >= 51)) {
                                        arrayRetrievedCardsPlayer2[++i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                                    }
                                    if (!(++i >= 51)) {
                                        arrayRetrievedCardsPlayer2[++i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                                    }
                                    if (!(++i >= 51)) {
                                        arrayRetrievedCardsPlayer2[++i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                                    }
                                    if (!(++i >= 51)) {
                                        arrayRetrievedCardsPlayer2[++i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                                    }
                                    if (!(++i >= 51)){
                                        arrayRetrievedCardsPlayer2[++i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                                    }
                                    if (!(++i >= 51)) {
                                        arrayRetrievedCardsPlayer2[++i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                                    }
                                    if (!(++i >= 51)) {
                                        arrayRetrievedCardsPlayer2[++i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                                    }
                                    break;
                                }
                            }
                            player1TakenCards += 10;
                            player2CountDeck -= 5;
                            player1CountDeck -= 5;
                            player2thridCardIsHigher = false;
                        }
                    }
                }
            }
        }
        int count = 0;
        if (player1TakenCards > player2TakenCards) {
            System.out.println("Player 1 " + player1.getName() + " wins the game ");
            System.out.println("Player 1 " + player1.getName() + " taken cards are: ");
            System.out.println();
            for (Card card : arrayRetrievedCardsPlayer1) {
                if (card != null) {
                    count++;
                    System.out.println(card.getName());
                }
            }
            if (count != player1TakenCards) {
                for (int i = count; i < player1TakenCards; i++) {
                    if (i < 51) {
                        arrayRetrievedCardsPlayer1[i] = cardDeckPlayer2.getRandom(cardDeckPlayer2.getCards());
                        System.out.println(arrayRetrievedCardsPlayer1[i].getName());
                        count++;
                    }
                }
            }
        } else {
            System.out.println("Player 2 " + player2.getName() + " wins the game ");
            System.out.println("Player 2 " + player2.getName() + " taken cards are: ");
            System.out.println();
            for (Card card : arrayRetrievedCardsPlayer2) {
                if (card != null) {
                    count++;
                    System.out.println(card.getName());
                }
            }
            if (count != player2TakenCards) {
                for (int i = count; i < player2TakenCards; i++) {
                    if (i < 51) {
                        arrayRetrievedCardsPlayer2[i] = cardDeckPlayer1.getRandom(cardDeckPlayer1.getCards());
                        System.out.println(arrayRetrievedCardsPlayer2[i].getName());
                        count++;
                    }
                }
            }
        }
        System.out.println();
        System.out.println("Number of taken cards: " + count);
    }
}